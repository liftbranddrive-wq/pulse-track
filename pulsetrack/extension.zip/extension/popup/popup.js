/* global chrome */

const LS = {
  access: 'pulsetrack_access',
  refresh: 'pulsetrack_refresh',
  apiBase: 'pulsetrack_api_base',
  sessionId: 'pulsetrack_session_id',
  paused: 'pulsetrack_paused',
  lastActivity: 'pulsetrack_last_activity',
  l1Sent: 'pulsetrack_l1_sent',
  l2Sent: 'pulsetrack_l2_sent',
  l3Reached: 'pulsetrack_l3_sent',
  l1Min: 'pulsetrack_l1_min',
  l2Min: 'pulsetrack_l2_min',
  l3Min: 'pulsetrack_l3_min',
  clockStarted: 'pulsetrack_clock_in_started_at',
  reportUrl: 'pulsetrack_report_url',
  liveActiveMs: 'pulsetrack_live_active_ms',
  sessionStatus: 'pulsetrack_session_status',
};

const THRESH = { l1: 5, l2: 10, l3: 15 };

const motivational = [
  'Small consistent steps beat frantic sprints.',
  'Your active minutes are saved automatically every few minutes.',
  'Thanks for staying honest about your hours.',
];

const qs = (id) => document.getElementById(id);

let tickHandle = null;
let pollHandle = null;
let liveActiveBase = 0;
let liveActiveAnchor = 0;

async function blobGet(key) {
  const x = await chrome.storage.local.get(key);
  return x[key];
}

async function blobPut(obj) {
  await chrome.storage.local.set(obj);
}

function apiUrl() {
  const el = qs('apiBase');
  return ((el?.value || '') || 'https://api.liftbrandfulfillment.com').replace(/\/$/, '');
}

function friendlyApiError(status, text, base) {
  const looksHtml = /<\s*html/i.test(text || '');
  if (looksHtml || status === 405) {
    if (/admin\./i.test(base) || text?.includes('405')) {
      return (
        'Wrong Company API URL.\n\n' +
        'Use: https://api.liftbrandfulfillment.com\n' +
        '(not the admin website).'
      );
    }
    return `Server error (${status || 'unknown'}). Use https://api.liftbrandfulfillment.com`;
  }
  const trimmed = (text || '').trim();
  if (trimmed.length > 200) return `Server error (${status}). Check Company API URL.`;
  return trimmed || `Request failed (${status})`;
}

async function apiFetch(path, opts = {}) {
  const base = apiUrl();
  await blobPut({ [LS.apiBase]: base });

  const token = await blobGet(LS.access);
  if (!token && !opts.skipAuth) throw new Error('Not signed in');

  const headers = new Headers(opts.headers || {});
  if (!opts.skipAuth && token) headers.set('Authorization', `Bearer ${token}`);
  headers.set('Accept', 'application/json');
  if (opts.body && !(opts.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  const res = await fetch(`${base}${path}`, { ...opts, headers });
  const text = await res.text();
  let data;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = null;
  }
  if (!res.ok) {
    throw new Error((data && data.error) || friendlyApiError(res.status, text, base));
  }
  return data;
}

async function applyIdleThresholds() {
  await blobPut({
    [LS.l1Min]: THRESH.l1,
    [LS.l2Min]: THRESH.l2,
    [LS.l3Min]: THRESH.l3,
  });
}

async function login() {
  const email = qs('email').value.trim();
  const password = qs('password').value;
  const payload = await apiFetch('/api/auth/login/member', {
    skipAuth: true,
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });

  await blobPut({
    [LS.access]: payload.accessToken,
    [LS.refresh]: payload.refreshToken,
  });

  await applyIdleThresholds();
  qs('authView').classList.add('hidden');
  qs('appView').classList.remove('hidden');
  await refreshEverything();
}

async function clockInNow() {
  const s = await apiFetch('/api/sessions/clock-in', { method: 'POST' });
  await applyIdleThresholds();
  await blobPut({
    [LS.sessionId]: s.id,
    [LS.paused]: false,
    [LS.clockStarted]: Date.now(),
    [LS.lastActivity]: Date.now(),
    [LS.l1Sent]: false,
    [LS.l2Sent]: false,
    [LS.l3Reached]: false,
    [LS.sessionStatus]: 'WORKING',
    [LS.liveActiveMs]: 0,
  });
  toast('Clocked in — active time is tracking');
  await refreshEverything();
}

async function clockOutNow() {
  const id = await blobGet(LS.sessionId);
  if (!id) return;

  await apiFetch('/api/sessions/clock-out', {
    method: 'POST',
    body: JSON.stringify({ sessionId: id }),
  });
  await blobPut({
    [LS.sessionId]: '',
    [LS.paused]: false,
    [LS.clockStarted]: 0,
    [LS.sessionStatus]: '',
    [LS.liveActiveMs]: 0,
  });
  toast('Clocked out — today saved on server');
  await refreshEverything();
}

async function startBreakFlow() {
  const id = await blobGet(LS.sessionId);
  const type = qs('breakType').value;
  await apiFetch('/api/sessions/break/start', {
    method: 'POST',
    body: JSON.stringify({ sessionId: id, type }),
  });
  toast('Break started');
  await refreshEverything();
}

async function endBreakFlow() {
  const id = await blobGet(LS.sessionId);
  await apiFetch('/api/sessions/break/end', {
    method: 'POST',
    body: JSON.stringify({ sessionId: id }),
  });
  await blobPut({ [LS.lastActivity]: Date.now(), [LS.l1Sent]: false, [LS.l2Sent]: false, [LS.l3Reached]: false });
  toast('Back to work');
  await refreshEverything();
}

async function pauseManual() {
  const id = await blobGet(LS.sessionId);
  await apiFetch('/api/sessions/pause', { method: 'POST', body: JSON.stringify({ sessionId: id }) });
  await blobPut({ [LS.paused]: true, [LS.sessionStatus]: 'PAUSED_MANUAL' });
  toast('Paused — not counting active time');
  await refreshEverything();
}

async function resumeManual() {
  const id = await blobGet(LS.sessionId);
  await apiFetch('/api/sessions/resume', { method: 'POST', body: JSON.stringify({ sessionId: id }) });
  await blobPut({
    [LS.paused]: false,
    [LS.lastActivity]: Date.now(),
    [LS.sessionStatus]: 'WORKING',
    [LS.l1Sent]: false,
    [LS.l2Sent]: false,
    [LS.l3Reached]: false,
  });
  toast('Resumed');
  await refreshEverything();
}

async function resumeFocus() {
  const id = await blobGet(LS.sessionId);
  await apiFetch('/api/sessions/reminder/ack', {
    method: 'POST',
    body: JSON.stringify({ sessionId: id, level: 'L3' }),
  }).catch(() => {});
  await apiFetch('/api/sessions/state/resume-focus', {
    method: 'POST',
    body: JSON.stringify({ sessionId: id }),
  });
  await blobPut({
    [LS.lastActivity]: Date.now(),
    [LS.l1Sent]: false,
    [LS.l2Sent]: false,
    [LS.l3Reached]: false,
    [LS.paused]: false,
    [LS.sessionStatus]: 'WORKING',
  });
  toast('Focus resumed — active time counting again');
  await refreshEverything();
}

function toast(line) {
  const el = qs('toast');
  if (el) el.textContent = line;
}

function format(ms) {
  const sec = Math.floor(ms / 1000);
  const hh = Math.floor(sec / 3600);
  const mm = Math.floor((sec % 3600) / 60);
  const ss = sec % 60;
  return [hh, mm, ss].map((n) => String(n).padStart(2, '0')).join(':');
}

function setTimerHint(session) {
  const hint = qs('timerHint');
  if (!hint) return;
  if (!session) {
    hint.textContent = 'Clock in to start tracking';
    return;
  }
  if (session.status === 'GHOST') {
    hint.textContent = 'Paused — 15 min no activity (ghost time recording)';
    return;
  }
  if (session.status === 'IDLE') {
    hint.textContent = 'Active time paused — move mouse/keyboard';
    return;
  }
  if (session.status === 'ON_BREAK') {
    hint.textContent = 'On break — active time not counting';
    return;
  }
  if (session.status === 'PAUSED_MANUAL') {
    hint.textContent = 'Manual pause — tap Resume when working';
    return;
  }
  hint.textContent = 'Auto-pause after 15 min with no mouse/keyboard';
}

function stopTicker() {
  if (tickHandle) clearInterval(tickHandle);
  tickHandle = null;
  liveActiveBase = 0;
  liveActiveAnchor = 0;
}

function startTicker(session, liveMs) {
  stopTicker();
  const frozen = session.status === 'GHOST' || session.status === 'IDLE' || session.status === 'PAUSED_MANUAL' || session.status === 'ON_BREAK';
  liveActiveBase = liveMs;
  liveActiveAnchor = frozen ? 0 : Date.now();

  const tick = () => {
    const extra = frozen ? 0 : Date.now() - liveActiveAnchor;
    qs('timer').textContent = format(liveActiveBase + extra);
  };
  tick();
  tickHandle = setInterval(tick, 500);
}

function stopPoll() {
  if (pollHandle) clearInterval(pollHandle);
  pollHandle = null;
}

function startPoll() {
  stopPoll();
  pollHandle = setInterval(() => refreshEverything().catch(() => {}), 12_000);
}

async function syncLiveFromServer(activePayload) {
  const session = activePayload?.session ?? activePayload;
  const liveMs = activePayload?.liveActiveMs ?? session?.totalActiveMs ?? 0;
  if (session?.id) {
    await blobPut({
      [LS.liveActiveMs]: liveMs,
      [LS.sessionStatus]: session.status,
    });
  }
  return { session, liveMs };
}

async function refreshEverything() {
  const token = await blobGet(LS.access);
  if (!token) {
    qs('authView').classList.remove('hidden');
    qs('appView').classList.add('hidden');
    qs('apiBase').value = (await blobGet(LS.apiBase)) || 'https://api.liftbrandfulfillment.com';
    stopTicker();
    stopPoll();
    return;
  }

  qs('authView').classList.add('hidden');
  qs('appView').classList.remove('hidden');

  let me = null;
  try {
    me = await apiFetch('/api/auth/me');
  } catch {}

  qs('userName').textContent = me?.name || 'Team member';
  qs('avatar').textContent = ((me?.name || 'LB').split(/\s+/g).map((p) => p[0]).slice(0, 2).join('')).toUpperCase();

  await applyIdleThresholds();

  let activePayload = null;
  try {
    activePayload = await apiFetch('/api/sessions/active');
  } catch {}

  const { session: serverSession, liveMs } = await syncLiveFromServer(activePayload);

  if (serverSession?.id && serverSession.clockOut === null) {
    await blobPut({
      [LS.sessionId]: serverSession.id,
      [LS.paused]: serverSession.status === 'PAUSED_MANUAL',
    });
    hydrateControls(serverSession);
    setTimerHint(serverSession);
    startTicker(serverSession, liveMs);
    startPoll();
  } else {
    await logoutSessionLocal();
    hydrateControlsClosed();
    setTimerHint(null);
    stopTicker();
    stopPoll();
    qs('clockInBtn').classList.remove('hidden');
    qs('clockOutBtn').classList.add('hidden');
    qs('breakBtn').classList.add('hidden');
    qs('resumeBtn').classList.add('hidden');
    qs('resumeFocusBtn').classList.add('hidden');
    qs('pauseBtn').classList.add('hidden');
    qs('manualResumeBtn').classList.add('hidden');
    qs('breakRow')?.classList.add('hidden');
  }

  try {
    const sum = await apiFetch('/api/sessions/today');
    const w = +(sum.workMs / 3_600_000).toFixed(2);
    const b = +(sum.breakMs / 3_600_000).toFixed(2);
    const i = +(sum.idleMs / 3_600_000).toFixed(2);
    const g = +(sum.ghostMs / 3_600_000).toFixed(2);
    qs('todaySummary').innerHTML =
      `<span><strong>Active</strong> ${w}h</span> · ` +
      `<span><strong>Break</strong> ${b}h</span> · ` +
      `<span><strong>Idle</strong> ${i}h</span> · ` +
      `<span><strong>Ghost</strong> ${g}h</span><br/>` +
      `<span class="muted-inline">${sum.sessions} session(s) today</span>`;
    qs('quote').textContent = motivational[(sum?.sessions ?? 0) % motivational.length];
  } catch {
    qs('todaySummary').textContent = 'Could not load today — check API URL';
  }

  qs('apiBase').value = (await blobGet(LS.apiBase)) || 'https://api.liftbrandfulfillment.com';
}

async function logoutSessionLocal() {
  await blobPut({
    [LS.sessionId]: '',
    [LS.clockStarted]: 0,
    [LS.paused]: false,
  });
}

function hydrateControls(session) {
  const manualPaused = session.status === 'PAUSED_MANUAL';
  const idleish = session.status === 'IDLE' || session.status === 'GHOST';
  const onBreak = session.status === 'ON_BREAK';
  const working = session.status === 'WORKING' && !manualPaused && !idleish;

  qs('pill').dataset.state =
    onBreak ? 'break' :
    session.status === 'GHOST' ? 'danger' :
    idleish || manualPaused ? 'idle' :
    working ? 'working' : '';

  qs('pill').textContent =
    onBreak ? 'On break' :
    session.status === 'GHOST' ? 'Ghost — timer paused' :
    session.status === 'IDLE' ? 'Idle — no activity' :
    session.status === 'PAUSED_MANUAL' ? 'Paused manually' :
    'Working';

  qs('clockOutBtn').classList.remove('hidden');
  qs('clockInBtn').classList.add('hidden');
  qs('breakRow')?.classList.toggle('hidden', !working && !onBreak);

  qs('breakBtn').classList.toggle('hidden', onBreak || manualPaused || idleish);
  qs('resumeBtn').classList.toggle('hidden', !onBreak);
  qs('resumeFocusBtn').classList.toggle('hidden', !idleish);
  qs('pauseBtn').classList.toggle('hidden', onBreak || manualPaused || idleish);
  qs('manualResumeBtn').classList.toggle('hidden', !manualPaused);
}

function hydrateControlsClosed() {
  qs('pill').dataset.state = '';
  qs('pill').textContent = 'Clocked out';
  qs('timer').textContent = '00:00:00';
}

function wireAuth() {
  qs('loginBtn').addEventListener('click', () => login().catch((e) => alert(e.message)));
}

function wireWork() {
  qs('clockInBtn').addEventListener('click', () => clockInNow().catch((e) => alert(e.message)));
  qs('clockOutBtn').addEventListener('click', () => clockOutNow().catch((e) => alert(e.message)));
  qs('breakBtn').addEventListener('click', () => startBreakFlow().catch((e) => alert(e.message)));
  qs('resumeBtn').addEventListener('click', () => endBreakFlow().catch((e) => alert(e.message)));
  qs('pauseBtn').addEventListener('click', () => pauseManual().catch((e) => alert(e.message)));
  qs('manualResumeBtn').addEventListener('click', () => resumeManual().catch((e) => alert(e.message)));
  qs('resumeFocusBtn').addEventListener('click', () => resumeFocus().catch((e) => alert(e.message)));
}

(async () => {
  qs('apiBase').value = (await blobGet(LS.apiBase)) || 'https://api.liftbrandfulfillment.com';
  wireAuth();
  wireWork();
  await refreshEverything();
})();
